import pytest

from modules.backend_tests.general.request_builder_asteroids import AsteroidRequestBuilder
from core.constants import HTTPStatusCodes


@pytest.mark.smoke
def test_smoke(asteroid_helper):
    result = asteroid_helper.fetch_data()
    assert 'count' in result


@pytest.mark.regression
def test_date_filter(asteroid_helper):
    params = AsteroidRequestBuilder().with_date_range("2025-01-01", "2025-01-10").build()
    result = asteroid_helper.fetch_data(**params)
    assert 'data' in result


@pytest.mark.regression
def test_invalid_param(asteroid_helper):
    result = asteroid_helper.fetch_data(expected_status_code=HTTPStatusCodes.BAD_REQUEST.value, invalid="param")
    assert 'one or more query parameter was not recognized', 'moreInfo' in result


@pytest.mark.regression
def test_edge_case_no_data(asteroid_helper):
    params = AsteroidRequestBuilder().with_date_range("3000-01-01", "3000-01-10").build()
    result = asteroid_helper.fetch_data(**params)
    assert result.get("count") == 0
