# Asteroids API Tests

## How to Run

```bash
make test
```

## Using Docker

```bash
make docker-build
make docker-run
```

## Reports

- HTML: `reports/report.html`
- JUnit XML: `reports/junit.xml`
